### Hexlet tests and linter status:
[![Actions Status](https://github.com/Spring-Silver-Bird/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Spring-Silver-Bird/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c6d4902fcfb210a114c9/maintainability)](https://codeclimate.com/github/Spring-Silver-Bird/python-project-lvl1/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/c6d4902fcfb210a114c9/test_coverage)](https://codeclimate.com/github/Spring-Silver-Bird/python-project-lvl1/test_coverage)

### Asciinema for brain-even:

https://asciinema.org/a/RHIhaOZDFPRzXaYfad9UqNYET

### Asciinema for brain-calc:


### Asciinema for brain-gcd:

https://asciinema.org/a/GgkZW1Q5b5TsMy2kqZ34Z2BTJ

### Asciinema for brain-progression: