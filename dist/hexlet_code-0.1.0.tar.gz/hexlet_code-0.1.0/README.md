### Hexlet tests and linter status:
[![Actions Status](https://github.com/Spring-Silver-Bird/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Spring-Silver-Bird/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/c6d4902fcfb210a114c9/maintainability)](https://codeclimate.com/github/Spring-Silver-Bird/python-project-lvl1/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/c6d4902fcfb210a114c9/test_coverage)](https://codeclimate.com/github/Spring-Silver-Bird/python-project-lvl1/test_coverage)

### Asciinema for brain-games:

https://asciinema.org/connect/955f2ce8-f869-4a68-97cd-fd48fa926ceb

### Asciinema for brain-even:

https://asciinema.org/a/DoZHzVT1zyo0QsRWEqOFaYhZr

### Asciinema for brain-calc:

https://asciinema.org/a/zB9xkO3ZFjluQQ3C6hMjOwwfl

### Asciinema for brain-gcd:

https://asciinema.org/a/GgkZW1Q5b5TsMy2kqZ34Z2BTJ

### Asciinema for brain-progression:

https://asciinema.org/connect/955f2ce8-f869-4a68-97cd-fd48fa926ceb

### Asciinema for brain-prime:

https://asciinema.org/connect/955f2ce8-f869-4a68-97cd-fd48fa926ceb